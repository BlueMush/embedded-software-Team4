package parsing;

import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class List_Title {

    private int num = 0;

    private ArrayList<String> busRouteId = new ArrayList<>();
    private ArrayList<String> busRouteNm = new ArrayList<>();
    private ArrayList<String> length = new ArrayList<>();
    private ArrayList<String> routeType = new ArrayList<>();
    private ArrayList<String> stStationNm = new ArrayList<>();
    private ArrayList<String> edStationNm = new ArrayList<>();
    private ArrayList<String> term = new ArrayList<>();
    private ArrayList<String> lastBusYn = new ArrayList<>();
    private ArrayList<String> firstBusTm = new ArrayList<>();
    private ArrayList<String> lastBusTm = new ArrayList<>();
    private ArrayList<String> firstLowTm = new ArrayList<>();
    private ArrayList<String> lastLowTm = new ArrayList<>();
    private ArrayList<String> corpNm = new ArrayList<>();

    public List_Title() {

    }

    // tag값의 정보를 가져오는 메소드
    public static String getTagValue(String tag, Element eElement) {
        try {
            String result = eElement.getElementsByTagName(tag).item(0).getTextContent();
            return result;
        } catch (NullPointerException e) {
            return "";
        } catch (Exception e) {
            return "";
        }

    }

    public List_Title(String list_space) {

        try {

            Choose_Url cu = new Choose_Url();
            String url = cu.view_List(list_space);
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = f.newDocumentBuilder();

            Document doc = null;
            doc = parser.parse(url);
            doc.getDocumentElement().normalize();

            // 파싱할 tag
            NodeList nList = doc.getElementsByTagName("itemList");
            num = nList.getLength();
            System.out.println("정보 개수 : " + num);

            // 하위 엘리먼트 접근
            for (int temp = 0; temp < num; temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;

                    busRouteId.add(getTagValue("busRouteId", eElement));
                    System.out.println(busRouteId.get(temp));
                    
                    busRouteNm.add(getTagValue("busRouteNm", eElement));
                    System.out.println(busRouteNm.get(temp));
                    
                    length.add(getTagValue("length", eElement));
                    System.out.println(length.get(temp));
                    
                    routeType.add(getTagValue("routeType", eElement));
                    System.out.println(routeType.get(temp));
                    
                    stStationNm.add(getTagValue("stStationNm", eElement));
                    System.out.println(stStationNm.get(temp));
                    
                    edStationNm.add(getTagValue("edStationNm", eElement));
                    System.out.println(edStationNm.get(temp));
                    
                    term.add(getTagValue("term", eElement));
                    System.out.println(term.get(temp));
                    
                    lastBusYn.add(getTagValue("lastBusYn", eElement));
                    System.out.println(lastBusYn.get(temp));
                    
                    firstBusTm.add(getTagValue("firstBusTm", eElement));
                    System.out.println(firstBusTm.get(temp));
                    
                    lastBusTm.add(getTagValue("lastBusTm", eElement));
                    System.out.println(lastBusTm.get(temp));
                    
                    firstLowTm.add(getTagValue("firstLowTm", eElement));
                    System.out.println(firstLowTm.get(temp));
                    
                    lastLowTm.add(getTagValue("lastLowTm", eElement));
                    System.out.println(lastLowTm.get(temp));
                    
                    corpNm.add(getTagValue("corpNm", eElement));
                    System.out.println(corpNm.get(temp));
                    System.out.println("-----------------------------------------------------------------");
                } // if end(nodeType)

            } // for end (print)

            List_Space.busRouteId = busRouteId;
            List_Space.busRouteNm = busRouteNm;
            List_Space.length = length;
            List_Space.routeType = routeType;
            List_Space.stStationNm = stStationNm;
            List_Space.edStationNm = edStationNm;
            List_Space.term = term;
            List_Space.lastBusYn = lastBusYn;
            List_Space.firstBusTm = firstBusTm;
            List_Space.lastBusTm = lastBusTm;
            List_Space.firstLowTm = firstLowTm;
            List_Space.lastLowTm = lastLowTm;
            List_Space.corpNm = corpNm;
            
        } catch (Exception e) {
            e.printStackTrace();
        } // try~catch end
    }

}
