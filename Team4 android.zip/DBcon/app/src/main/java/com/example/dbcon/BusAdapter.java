package com.example.dbcon;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.widget.Toast.LENGTH_LONG;
import static android.widget.Toast.LENGTH_SHORT;


class BusAdapter extends RecyclerView.Adapter<BusAdapter.CustomViewHolder> {
    ArrayList<BusData> mList = null;
    private Activity context = null;
    BusData busData = new BusData();
    String po;
    int pos;




    public BusAdapter(MainActivity context, ArrayList<BusData> list) {
        this.context = context;
        this.mList = list;

    }


    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list, null);
        CustomViewHolder viewHolder = new CustomViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewholder, int position) {
        viewholder.id.setText(mList.get(position).get_stNm());
        viewholder.onBind(mList.get(position));



    }


    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }

    class CustomViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView id;
        private BusData data;
        private ImageView imageView;

        public CustomViewHolder(View view) {
            super(view);
            this.id = (TextView) view.findViewById(R.id.textView1);
            this.imageView =(ImageView)view.findViewById(R.id.imageView);
        }

        void onBind(BusData data) {
            id.setText(data.get_stNm());
            id.setOnClickListener(this);
            po = data.get_stNm();
        }

        public void onClick(View v) {

            po = mList.get(getAdapterPosition()).get_stNm();
            pos = getAdapterPosition();

            switch (v.getId()) {
                case R.id.textView1:

                    ((MainActivity)MainActivity.mContext).show(po,pos);
                    Log.d("dd", String.valueOf(v.getId()));

            }

        }
    }
}