package com.example.dbcon;

public class BusData {
    private String stNm;

    public String get_stNm() {
        return stNm;
    }
    public void set_stNm(String stNm) {
        this.stNm = stNm;
    }
}
