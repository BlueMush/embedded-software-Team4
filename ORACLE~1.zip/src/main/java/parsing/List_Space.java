package parsing;

import java.util.ArrayList;

public class List_Space {

    public static ArrayList<String> busRouteId = new ArrayList<>();
    public static ArrayList<String> busRouteNm = new ArrayList<>();
    public static ArrayList<String> length = new ArrayList<>();
    public static ArrayList<String> routeType = new ArrayList<>();
    public static ArrayList<String> stStationNm = new ArrayList<>();
    public static ArrayList<String> edStationNm = new ArrayList<>();
    public static ArrayList<String> term = new ArrayList<>();
    public static ArrayList<String> lastBusYn = new ArrayList<>();
    public static ArrayList<String> firstBusTm = new ArrayList<>();
    public static ArrayList<String> lastBusTm = new ArrayList<>();
    public static ArrayList<String> firstLowTm = new ArrayList<>();
    public static ArrayList<String> lastLowTm = new ArrayList<>();
    public static ArrayList<String> corpNm = new ArrayList<>();

}
