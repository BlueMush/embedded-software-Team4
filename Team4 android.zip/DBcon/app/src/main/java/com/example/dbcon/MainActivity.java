package com.example.dbcon;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private static String IP_ADDRESS = "113.198.236.181:80";
    public static Context mContext;
    String  station1;//현재버스위치
    String  station2;//이전버스위치.
    String nextStTm1;//다음정류장까지 남은 버스 시간
    String selectName;//팝업에서 도착지 선택한 변수.
    int pos;
    ImageButton imageButton;
    TextView htextview;
    TextView destview;


    private ArrayList<BusData> mArrayList;
    private ArrayList<String> bArrayList;
    private BusAdapter mAdapter;
    private RecyclerView mRecyclerView;
    private String mJsonString;

    // mConnectedDeviceName : 블루투스 이름 -> 즉 차량 고유 id


    private final int REQUEST_BLUETOOTH_ENABLE = 100;

    private TextView mConnectionStatus;

    ConnectedTask mConnectedTask = null;
    static BluetoothAdapter mBluetoothAdapter;
    private String mConnectedDeviceName = null;
    private ArrayAdapter<String> mConversationArrayAdapter;
    static boolean isConnectionError = false;
    ImageView imageView;
    static int counter = 0;

    DeviceName deviceName = new DeviceName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        destview= findViewById(R.id.destname);
        imageButton = findViewById(R.id.replay);
        imageView = (ImageView) findViewById(R.id.imageView);
        mRecyclerView = (RecyclerView) findViewById(R.id.listView_main_list);
        Button button_all = (Button) findViewById(R.id.button_main_all);
        mConnectionStatus = (TextView) findViewById(R.id.connection_status_textview);
        ListView mMessageListview = (ListView) findViewById(R.id.message_listview);
        htextview = findViewById(R.id.hpos);
        mContext = this;


        mConversationArrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1);
        mMessageListview.setAdapter(mConversationArrayAdapter);

        Log.d("df", "Initalizing Bluetooth adapter...");

        // 디바이스에서 블루투스를 지원하는지 체크합니다.
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            showErrorDialog("This device is not implement Bluetooth.");
            return;
        }

        if (!mBluetoothAdapter.isEnabled()) {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, REQUEST_BLUETOOTH_ENABLE);
        } else {
            Log.d("dg", "Initialisation successful.");

            showPairedDevicesListDialog();

        }
//--- 리사이클러뷰 작업
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mArrayList = new ArrayList<>();
        mAdapter = new BusAdapter(this, mArrayList);
        mRecyclerView.setAdapter(mAdapter);


        Button OnButton = findViewById(R.id.btn_on);
        Button OffButton = findViewById(R.id.btn_off);
        Button OsndoButton = findViewById(R.id.btn_onsdo);


        OsndoButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String sendMessage = "2";
                switch (sendMessage) {
                    case "2":
                        sendMessage("2");
                        break;
                }
            }
        });
        OnButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String sendMessage = "1";
                switch (sendMessage) {
                    case "1":

                        sendMessage("1");

                        break;
                }
            }
        });
        OffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sendMessage = "0";
                switch (sendMessage) {
                    case "0":
                        sendMessage("0");
                        break;
                }
            }
        });


        button_all.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                mArrayList.clear();
                mAdapter.notifyDataSetChanged();

                GetData task = new GetData();
                task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "http://" + IP_ADDRESS + "/query2.php", "");
            }
        });

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetData2 task = new GetData2();
                Log.d("123name", "123name" + deviceName.getName());
                task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "http://" + IP_ADDRESS + "/query.php", deviceName.getName());
                Log.d("pos값","pos값"+pos);
            }
        });


    }

    //---------------------팝업창 메소드
    public void show(final String name,final int pos1) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(name);
        builder.setMessage("이 정류장에 하차를 예약하시겠습니까");
        builder.setPositiveButton("예",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "예를 선택했습니다.", Toast.LENGTH_SHORT).show();
                        selectName = name;
                        destview.setText(selectName);
                        pos  = pos1;
                        Log.d("누른pos:","누른pos:"+pos1);


                    }
                });
        builder.setNegativeButton("아니오",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "아니오를 선택했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
        builder.show();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("des123", "des123");
        if (mConnectedTask != null) {

            mConnectedTask.cancel(true);
        }
    }

    //------------------------------------------------------------블루투스
    private class ConnectTask extends AsyncTask<Void, Void, Boolean> {

        private BluetoothSocket mBluetoothSocket = null;
        private BluetoothDevice mBluetoothDevice = null;

        ConnectTask(BluetoothDevice bluetoothDevice) {
            mBluetoothDevice = bluetoothDevice;
            mConnectedDeviceName = bluetoothDevice.getName();

            //SPP
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

            try {
                mBluetoothSocket = mBluetoothDevice.createRfcommSocketToServiceRecord(uuid);
                Log.d("dd", "create socket for " + mConnectedDeviceName);
                deviceName.setName(mConnectedDeviceName);

            } catch (IOException e) {
                Log.e("dd", "socket create failed " + e.getMessage());
            }


            mConnectionStatus.setText("connecting...");
        }


        @Override
        protected Boolean doInBackground(Void... params) {

            // Always cancel discovery because it will slow down a connection
            mBluetoothAdapter.cancelDiscovery();

            // Make a connection to the BluetoothSocket
            try {
                // This is a blocking call and will only return on a
                // successful connection or an exception
                mBluetoothSocket.connect();
            } catch (IOException e) {
                // Close the socket
                try {
                    mBluetoothSocket.close();
                } catch (IOException e2) {
                    Log.e("dd", "unable to close() " +
                            " socket during connection failure", e2);
                }

                return false;
            }

            return true;
        }


        @Override
        protected void onPostExecute(Boolean isSucess) {

            if (isSucess) {
                connected(mBluetoothSocket);
                GetData2 task = new GetData2();
                Log.d("123name", "123name" + deviceName.getName());
                task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "http://" + IP_ADDRESS + "/query.php", deviceName.getName());
                //다음정류장 남은시간만큼계속 반복 해줘야함. 이상적임. 오차범위 -30.
              /*  while (true) {
                    try {
                        Thread.sleep(30000);
                        Thread.sleep((Integer.parseInt(nextStTm1) * 1000) - 30000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Log.d("실패", "실패" + e);
                    }

                }*///while문
            } else {

                isConnectionError = true;
                Log.d("dd", "Unable to connect device");
                showErrorDialog("Unable to connect device");
            }
        }
    }

    //----블루투스 연결
    public void connected(BluetoothSocket socket) {
        mConnectedTask = new ConnectedTask(socket);
        mConnectedTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }


    private class ConnectedTask extends AsyncTask<Void, String, Boolean> {

        private InputStream mInputStream = null;
        private OutputStream mOutputStream = null;
        private BluetoothSocket mBluetoothSocket = null;

        ConnectedTask(BluetoothSocket socket) {

            mBluetoothSocket = socket;
            try {
                mInputStream = mBluetoothSocket.getInputStream();
                mOutputStream = mBluetoothSocket.getOutputStream();
            } catch (IOException e) {
                Log.e("dd", "socket not created", e);
            }

            Log.d("dd", "connected to " + mConnectedDeviceName);
            deviceName.setName(mConnectedDeviceName);
            mConnectionStatus.setText("connected to " + mConnectedDeviceName);
        }


        @Override
        protected Boolean doInBackground(Void... params) {

            byte[] readBuffer = new byte[1024];
            int readBufferPosition = 0;


            while (true) {

                if (isCancelled()) return false;

                try {

                    int bytesAvailable = mInputStream.available();

                    if (bytesAvailable > 0) {

                        byte[] packetBytes = new byte[bytesAvailable];

                        mInputStream.read(packetBytes);

                        for (int i = 0; i < bytesAvailable; i++) {

                            byte b = packetBytes[i];
                            if (b == '\n') {
                                byte[] encodedBytes = new byte[readBufferPosition];
                                System.arraycopy(readBuffer, 0, encodedBytes, 0,
                                        encodedBytes.length);
                                String recvMessage = new String(encodedBytes, "UTF-8");

                                readBufferPosition = 0;

                                Log.d("dd", "recv message: " + recvMessage);
                                publishProgress(recvMessage);
                            } else {
                                readBuffer[readBufferPosition++] = b;
                            }
                        }
                    }
                } catch (IOException e) {

                    Log.e("dd", "disconnected", e);
                    return false;
                }
            }

        }

        @Override
        protected void onProgressUpdate(String... recvMessage) {

            mConversationArrayAdapter.insert(mConnectedDeviceName + ": " + recvMessage[0], 0);
        }

        @Override
        protected void onPostExecute(Boolean isSucess) {
            super.onPostExecute(isSucess);

            if (!isSucess) {


                closeSocket();
                Log.d("dd", "Device connection was lost");
                isConnectionError = true;
                showErrorDialog("Device connection was lost");
                mArrayList.clear();
                mAdapter.notifyDataSetChanged();

                GetData task = new GetData();

                task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "http://" + IP_ADDRESS + "/query2.php", "");
            }
        }

        @Override
        protected void onCancelled(Boolean aBoolean) {
            super.onCancelled(aBoolean);

            closeSocket();
        }

        void closeSocket() {

            try {

                mBluetoothSocket.close();
                Log.d("dd", "close socket()");

            } catch (IOException e2) {

                Log.e("dd", "unable to close() " +
                        " socket during connection failure", e2);
            }
        }

        void write(String msg) {

            msg += "\n";

            try {
                mOutputStream.write(msg.getBytes());
                mOutputStream.flush();
            } catch (IOException e) {
                Log.e("dd", "Exception during send", e);
            }

//            mInputEditText.setText(" ");
        }
    }


    public void showPairedDevicesListDialog() {
        Set<BluetoothDevice> devices = mBluetoothAdapter.getBondedDevices();
        final BluetoothDevice[] pairedDevices = devices.toArray(new BluetoothDevice[0]);

        if (pairedDevices.length == 0) {
            showQuitDialog("No devices have been paired.\n"
                    + "You must pair it with another device.");
            return;
        }

        String[] items;
        items = new String[pairedDevices.length];
        for (int i = 0; i < pairedDevices.length; i++) {
            items[i] = pairedDevices[i].getName();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select device");
        builder.setCancelable(false);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                ConnectTask task = new ConnectTask(pairedDevices[which]);
                task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);


            }
        });
        builder.create().show();
    }


    public void showErrorDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quit");
        builder.setCancelable(false);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (isConnectionError) {
                    isConnectionError = false;
                    finish();
                }
            }
        });
        builder.create().show();
    }


    public void showQuitDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quit");
        builder.setCancelable(false);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });
        builder.create().show();
    }

    void sendMessage(String msg) {
        if (mConnectedTask != null) {
            mConnectedTask.write(msg);
            Log.d("dd", "send message: " + msg);
            //       mConversationArrayAdapter.insert("Me:  " + msg, 0);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_BLUETOOTH_ENABLE) {
            if (resultCode == RESULT_OK) {
                //BlueTooth is now Enabled
                showPairedDevicesListDialog();
            }
            if (resultCode == RESULT_CANCELED) {
                showQuitDialog("You need to enable bluetooth");
            }
        }
    }

    //------------------------------------------------------- 버스정류장
    private class GetData extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(MainActivity.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            //.setText(result);
            Log.d("dd", "response - " + result);

            if (result == null) {

            } else {
                mJsonString = result;
                showResult();
            }
        }

        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];
            String postParameters = params[1];

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d("dd", "response code - " + responseStatusCode);

                InputStream inputStream;
                if (responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                } else {
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }

                bufferedReader.close();


                return sb.toString().trim();


            } catch (Exception e) {

                Log.d("dd", "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }
        }
    }

    //-------------------버스실시간상태
    private class GetData2 extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;
        String errorString = null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(MainActivity.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            //.setText(result);
            Log.d("dd2", "response2 - " + result);

            if (result == null) {

            } else {
                mJsonString = result;
                showResult2();

            }
        }

        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];
            String postParameters = "vehId=" + params[1];

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d("dd2", "response code - " + responseStatusCode);

                InputStream inputStream;
                if (responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                } else {
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }

                bufferedReader.close();


                return sb.toString().trim();


            } catch (Exception e) {

                Log.d("dd2", "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }
        }
    }


    private void showResult() {
        String TAG_JSON = "webnautes";
        String TAG_ID = "stNm";


        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject item = jsonArray.getJSONObject(i);

                String stNm = item.getString(TAG_ID);


                BusData BusData = new BusData();

                BusData.set_stNm(stNm);


                mArrayList.add(BusData);
                mAdapter.notifyDataSetChanged();
            }

        } catch (JSONException e) {

            Log.d("dd", "showResult : ", e);
        }
    }

    //--------실시간위칭 값 json 파싱
    private void showResult2() {
        //여기서 미리 값을 파싱해서 붙여줘야함 현위치를.
        String TAG_JSON = "webnautes";
        String TAG_ID = "plainNo";
        String TAG_nextStTm = "nextStTm";
        String TAG_next = "nextStId";
        String TAG_number = "busnumber";

        bArrayList = new ArrayList<>();


        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject item = jsonArray.getJSONObject(i);

                String plainNo = item.getString(TAG_ID);
                String nextStTm = item.getString(TAG_nextStTm);
                String nextStId = item.getString(TAG_next);
                String busnumber = item.getString(TAG_number);


                BusState busState = new BusState();


                busState.setPlainNo(plainNo);
                busState.setNextStTm(nextStTm);
                busState.setNextStId(nextStId);
                busState.setBusnumber(busnumber);

                nextStTm1 = busState.getNextStTm();
                bArrayList.add(busState.getPlainNo());
                bArrayList.add(busState.getNextStTm());
                bArrayList.add(busState.getNextStId());
                bArrayList.add(busState.getBusnumber());


            }
            Log.d("버스현재위치","버스현재위치"+bArrayList.get(2));

            Log.d("pos값","pos값"+pos);
            if (Integer.parseInt(bArrayList.get(2)) == 107000274) {
                station1 ="서경대정문앞";
                station2="서경대본관";
                //이전 정류장 -> 서경대본관
                htextview.setText(station1);


            } else if (Integer.parseInt(bArrayList.get(2)) == 107000444) {
                //이전정류장 -> 서경대본관
                station1 ="서경로꿈마루도서관앞";
                station2="서경대정문앞";
                htextview.setText(station1);

            } else if (Integer.parseInt(bArrayList.get(2)) == 107000155) {
                //이전 정류장    서경로꿈마루도서관앞
                station1 ="길원초등학교입구";
                station2="서경로꿈마루도서관앞";
                htextview.setText(station1);

            } else if (Integer.parseInt(bArrayList.get(2)) == 107000156) {
                //이전 정류장  길원초등학교입구
                station1 ="열매교회";
                station2="길원초등학교입구";
                htextview.setText(station1);

            } else if (Integer.parseInt(bArrayList.get(2)) == 107000158) {
                //이전 정류장   열매교회
                station1 ="미화약국길음뉴타운8단지";
                station2="열매교회";
                htextview.setText(station1);


            } else if (Integer.parseInt(bArrayList.get(2)) == 107000280) {
                //이전 정류장  미화약국.길음뉴타운8단지
                station1 ="숭덕초교";
                station2="미화약국길음뉴타운8단지";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000162) {
                //이전 정류장   숭덕초교
                station1 ="숭덕초교1";
                station2="숭덕초교";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000029) {
                //이전 정류장    숭덕초교1
                station1 ="정릉길음시장";
                station2="숭덕초교1";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000031) {
                //이전 정류장   정릉길음시장
                station1 ="길음시장";
                station2="정릉길음시장";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000150) {
                //이전 정류장    길음시장
                station1 ="길음역";
                station2="길음시장";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000152) {
                //이전 길음역
                station1 ="성북우체국현대백화점";
                station2="길음역";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000231) {
                //이전 정류장   성북우체국현대백화점
                station1 ="숭곡초교입구";
                station2="성북우체국현대백화점";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000011) {
                //이전 정류장   숭곡초교입구
                station1 ="숭곡초교후문";
                station2="숭곡초교입구";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000501) {
                //이전 정류장    숭곡초교후문
                station1 ="월곡아남아파트";
                station2="숭곡초교후문";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000502) {
                //이전 정류장   월곡아남아파트
                station1 ="월곡동신아파트";
                station2="월곡아남아파트";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000500) {
                //이전 정류장    월곡동신아파트
                station1 ="kt월곡지사";
                station2="월곡동신아파트";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000039) {
                //이전 정류장    kt월곡지사
                station1 ="돈암1동주민센터";
                station2="kt월곡지사";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000036) {
                //이전 정류장   돈암1동주민센터
                station1 ="길음역1";
                station2="돈암1동주민센터";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000239) {
                //이전 정류장   길음역1
                station1 ="길음뉴타운10단지.라온유아파트";
                station2="길음역1";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000497) {
                //이전 정류장   길음뉴타운10단지.라온유아파트
                station1 ="숭덕초교2";
                station2="길음뉴타운10단지.라온유아파트1";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000030) {
                //이전  다음 정류장  숭덕초교2
                station1 ="정릉동태영아파트";
                station2="숭덕초교2";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000161) {
                //이전   정릉동태영아파트
                station1 ="미화약국길음뉴타운8단지1";
                station2="정릉동태영아파트";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000281) {
                //이전 정류장  미화약국.길음뉴타운8단지1
                station1 ="열매교회1";
                station2="미화약국길음뉴타운8단지1";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000159) {
                //이전 정류장    열매교회1
                station1 ="길원초등학교입구1";
                station2="열매교회1";
                htextview.setText(station1);
            } else if (Integer.parseInt(bArrayList.get(2)) == 107000157) {
                //이전 정류장 길원초등학교입구1
                station1 ="서경로꿈마도서관앞1";
                station2="길원초등학교입구1";
                htextview.setText(station1);
            }
            else{
                htextview.setText("차고지");
            }

            //--------벨조작키기

            if(station1.equals("서경대본관")){
                if(pos==1){
                    sendMessage("1");

                }
            }
            else if(station1.equals("서경대정문앞")){
                if(pos==2){
                    sendMessage("1");

                }
            }
            else if(station1.equals("서경로꿈마루도서관앞")){
                if(pos==3){
                    sendMessage("1");

                }
            }
            else if(station1.equals("길원초등학교입구")){
                if(pos==4){
                    sendMessage("1");

                }
            }
            else if(station1.equals("열매교회")){
                if(pos==5){
                    sendMessage("1");

                }
            }
            else if(station1.equals("미화약국길음뉴타운8단지")){
                if(pos==6){
                    sendMessage("1");

                }
            }
            else if(station1.equals("숭덕초교")){
                if(pos==7){
                    sendMessage("1");

                }
            }
            else if(station1.equals("숭덕초교1")){
                if(pos==8){
                    sendMessage("1");

                }
            }
            else if(station1.equals("정릉길음시장")){
                if(pos==9){
                    sendMessage("1");

                }
            }
            else if(station1.equals("길음시장")){
                if(pos==10){
                    sendMessage("1");

                }
            }
            else if(station1.equals("길음역")){
                if(pos==11){
                    sendMessage("1");

                }
            }
            else if(station1.equals("성북우체국현대백화점")){
                if(pos==12){
                    sendMessage("1");

                }
            }
            else if(station1.equals("숭곡초교입구")){
                if(pos==13){
                    sendMessage("1");

                }
            }
            else if(station1.equals("숭곡초교후문")){
                if(pos==14){
                    sendMessage("1");

                }
            }
            else if(station1.equals("월곡아남아파트")){
                if(pos==15){
                    sendMessage("1");

                }
            }
            else if(station1.equals("월곡동신아파트")){
                if(pos==16){
                    sendMessage("1");

                }
            }
            else if(station1.equals("kt월곡지사")){
                if(pos==17){
                    sendMessage("1");

                }
            }
            else if(station1.equals("돈암1동주민센터")){
                if(pos==18){
                    sendMessage("1");

                }
            }
            else if(station1.equals("길음역1")){
                if(pos==19){
                    sendMessage("1");

                }
            }
            else if(station1.equals("길음뉴타운10단지라온유아파트")){
                if(pos==20){
                    sendMessage("1");

                }
            }
            else if(station1.equals("숭덕초교2")){
                if(pos==21){
                    sendMessage("1");

                }
            }
            else if(station1.equals("정릉동태영아파트")){
                if(pos==22){
                    sendMessage("1");

                }
            }
            else if(station1.equals("미화약국길음뉴타운8단지1")){
                if(pos==23){
                    sendMessage("1");

                }
            }
            else if(station1.equals("열매교회1")){
                if(pos==24){
                    sendMessage("1");

                }
            }
            else if(station1.equals("길원초등학교입구1")){
                if(pos==25){
                    sendMessage("1");

                }
            }
            else {
                sendMessage("0");
            }

            TimerTask tt = new TimerTask() {
                @Override
                public void run() {
                    Log.d("1초에1씩", bArrayList.get(1));
                    Log.d("1초에1씩플",String.valueOf(counter));
                    counter++;
                    if(Integer.parseInt(bArrayList.get(1))==counter){
                        Log.d("1초에1씩플플","스탑");
                        cancel();
                        sendMessage("0");
                        counter=0;
                        run();
                    }

                }

            };
            Timer timer = new Timer();
            timer.schedule(tt,0,1000);


        } catch (JSONException e) {

            Log.d("dd2", "showResult : ", e);
        }

    }

}
