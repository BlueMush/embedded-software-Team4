/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.oracle;
import java.sql.*;
import oracle.jdbc.pool.OracleDataSource;

/**
 *
 * @author bhi84
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        OracleDataSource ods =null;
        Connection con = null;
        Statement stmt =null;
        ResultSet rs= null;
        PreparedStatement pstmt =null;
        //String query ="insert into userinfo(userid,userpassword,username,usergender,useremail)"+"values (?,?,?,?,?)";
        String query ="UPDATE userinfo set userid=?"+"where userid=?";
       
        
        try{
            ods = new OracleDataSource();
            ods.setURL("jdbc:oracle:thin:@sedb.deu.ac.kr:1521:orcl");
            ods.setUser("st2019013");
            ods.setPassword("2019013");
            con = ods.getConnection();
            stmt = con.createStatement();
           
             pstmt.executeUpdate(query); 
            //pstmt =con.prepareStatement(query);
          //  pstmt.setString(1,"gmp");
          // pstmt.setString(2,"gmp123");
         //   pstmt.setString(3,"배추도사");
           // pstmt.setString(4,"여");
           // pstmt.setString(5,"wwe@daum.net");
            
            int cnt = pstmt.executeUpdate();
            
        
             
            rs = stmt.executeQuery("select * from USERINFO");
            System.out.println("아이디\t    비밀번호\t 이름\t성별\t    메일");
          
           
            while(rs.next()){
                String userid = rs.getString(1);
                String r_id = rs.getString(2);
                String name = rs.getString(3);
                String gender = rs.getString(4);
                String mail = rs.getString(5);
             System.out.println(userid+"\t"+"    "+r_id+"\t"+name+"\t"+gender+"\t"+mail+"\t");
            } 
         } catch(Exception e){
             System.out.println(e);
         }
        finally {
                    try{if(pstmt != null) pstmt.close();
                        if(con != null) con.close();
                        if(stmt != null) stmt.close();
                        if(rs != null) rs.close();
                    }catch (Exception e){
                        System.out.println(e);
                        }
            }
    }
    
}
