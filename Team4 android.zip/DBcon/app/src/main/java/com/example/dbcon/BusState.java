package com.example.dbcon;
public class BusState {

    private String plainNo;
    private String nextStId;
    private String busnumber;
    private String nextStTm;

    public String getNextStTm() {
        return nextStTm;
    }

    public void setNextStTm(String nextStTm) {
        this.nextStTm = nextStTm;
    }

    public String getPlainNo() {
        return plainNo;
    }

    public void setPlainNo(String plainNo) {
        this.plainNo = plainNo;
    }

    public String getNextStId() {
        return nextStId;
    }

    public void setNextStId(String nextStId) {
        this.nextStId = nextStId;
    }

    public String getBusnumber() {
        return busnumber;
    }

    public void setBusnumber(String busnumber) {
        this.busnumber = busnumber;
    }
}
