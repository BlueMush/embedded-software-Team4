/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsing.busRouteList;

/**
 *
 * @author fkeke
 */
public class stationsByRouteListUrl {

    private final String publicUrl = "http://ws.bus.go.kr/api/rest/busRouteInfo/";
    private final String operation = "getStaionByRoute";
    private final String serviceKey = "ServiceKey=EexLJ1QY2YFGFoq1%2FXLc%2Bb3FCzpMPTRjqHUUQ57LX5Gg%2FaZTST3gwKFIFy0CZkExacp8bLt1Fni%2F%2BROVUn7LhA%3D%3D";
    private final String parameter = "&busRouteId=";
    private final String url = publicUrl + operation + "?" + serviceKey + parameter;
    private String busRouteId;

    public String getBusRouteId() {
        return busRouteId;
    }

    public void setBusRouteId(String busRouteId) {
        this.busRouteId = busRouteId;
    }
    
    public String getUrl() {
        return url;
    }

}