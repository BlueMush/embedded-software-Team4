/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsing.busPosByRtidList;

import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author fkeke
 */
public class busPosByRtidList {

    private int num = 0;

    public  ArrayList<String> vehId = new ArrayList<>(); // 버스 ID
    public  ArrayList<String> plainNo = new ArrayList<>(); // 차량번호
    public  ArrayList<String> nextStTm = new ArrayList<>(); // 다음 정류소 도착 소요시간
    public  ArrayList<String> lastStnId = new ArrayList<>(); // 다음 정류소 도착 소요시간
    //public  ArrayList<String> nextStId = new ArrayList<>(); // 다음 정류소 아이디

    // tag값의 정보를 가져오는 메소드
    public static String getTagValue(String tag, Element eElement) {
        try {
            String result = eElement.getElementsByTagName(tag).item(0).getTextContent();
            return result;
        } catch (NullPointerException e) {
            return "";
        } catch (Exception e) {
            return "";
        }

    }

    public void parsing(String busRouteId_) {

        try {

            busPosByRtidListUrl busUrl = new busPosByRtidListUrl();
            busUrl.setBusRouteId(busRouteId_);
            String view = busUrl.getUrl() + busUrl.getBusRouteId();

            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = f.newDocumentBuilder();

            Document doc = null;
            doc = parser.parse(view);
            doc.getDocumentElement().normalize();

            // 파싱할 tag
            NodeList nList = doc.getElementsByTagName("itemList");
            num = nList.getLength();
            System.out.println("정보 개수 : " + num);

            // 하위 엘리먼트 접근
            for (int temp = 0; temp < num; temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;

                    vehId.add(getTagValue("vehId", eElement));
                    //System.out.println(vehId.get(temp));

                    plainNo.add(getTagValue("plainNo", eElement));
                    //System.out.println(plainNo.get(temp));
                    nextStTm.add(getTagValue("nextStTm", eElement));
                    lastStnId.add(getTagValue("lastStnId", eElement));
                    //System.out.println(nextStTm.get(temp));

                    //nextStId.add(getTagValue("nextStId", eElement));
                    //System.out.println(nextStId.get(temp));

                    //System.out.println("-----------------------------------------------------------------");
                } // if end(nodeType)

            } // for end (print)

        } catch (Exception e) {
            e.printStackTrace();
        } // try~catch end
    }
}
