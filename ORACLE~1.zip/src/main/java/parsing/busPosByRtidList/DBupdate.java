/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsing.busPosByRtidList;

import java.sql.*;
import parsing.busPosByRtidList.busPosByRtidList;
import parsing.busRouteList.busRouteList;

/**
 *
 * @author gmp
 */
public class DBupdate {

    private Connection conn; // connection:db에접근하게 해주는 객체
    private PreparedStatement pstmt;
    Statement stmt = null;
    private ResultSet rs;
    String query = "insert into 1164state(vehId,plainNo,nextStTm,nextStId,busnumber)" + "values (?,?,?,?,?)";

    public DBupdate() {
        try {
            String dbURL = "jdbc:mysql://localhost:3306/testdb?characterEncoding=euckr"; // localhost:3306 포트는 컴퓨터설치된 mysql주소
            String dbID = "gmp";
            String dbPassword = "1234";
            Class.forName("com.mysql.jdbc.Driver");

            conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
            pstmt = conn.prepareStatement(query);

            int num = 0;

            busRouteList brl = new busRouteList();
            brl.parsing();

            int totalElements = brl.busRouteId.size();// arrayList의 요소의 갯수를 구한다.
            for (int index = 0; index < totalElements; index++) {
                if ("100100171".equals(brl.busRouteId.get(index))) {
                    num = index;
                }
            }

            busPosByRtidList bbrl = new busPosByRtidList();
            bbrl.parsing(brl.busRouteId.get(num));

            int totalElements1 = bbrl.vehId.size();// arrayList의 요소의 갯수를 구한다.
             pstmt.executeUpdate("TRUNCATE TABLE 1164state");
            for (int index = 0; index < totalElements1; index++) {
                pstmt.setString(1, bbrl.vehId.get(index));
                System.out.println(bbrl.vehId.get(index));
                pstmt.setString(2, bbrl.plainNo.get(index));
                pstmt.setString(3, bbrl.nextStTm.get(index));
                pstmt.setString(4, bbrl.lastStnId.get(index));
                pstmt.setString(5, brl.busRouteNm.get(num));
                 int r = pstmt.executeUpdate();
            }
           
 

           

        } catch (Exception e) {
            e.printStackTrace(); // 오류가 무엇인지 출력
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
