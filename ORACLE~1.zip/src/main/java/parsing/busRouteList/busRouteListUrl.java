/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package parsing.busRouteList;

/**
 *
 * @author fkeke
 */
public class busRouteListUrl {
    
    private final String publicUrl = "http://ws.bus.go.kr/api/rest/busRouteInfo/";
    private final String operation = "getBusRouteList";
    private final String serviceKey = "ServiceKey=f9INlZn0yuibo2dWPEf%2Fs1GGX6nxZnVrp7m70KD8ck3qKd7AbETrcZXUZzB25K30R%2B1Gb4F7vlw%2FMg6kVXzz0Q%3D%3D";
    private final String parameter = "&strSrch=";
    private final String url = publicUrl + operation + "?" + serviceKey + parameter;
    
    public String getUrl() {
        return url;
    }
    
}