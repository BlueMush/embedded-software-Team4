package parsing;

public class Main_Class {

    public static void main(String[] args) {

        new List_Title(Url_Info.busRList);
        //System.out.println(Detail_Space.total.get(7));
    }

}