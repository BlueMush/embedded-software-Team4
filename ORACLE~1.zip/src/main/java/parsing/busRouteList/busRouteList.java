/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsing.busRouteList;

import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 *
 * @author fkeke
 */

public class busRouteList {

    private int num = 0;

    public ArrayList<String> busRouteId = new ArrayList<>();
    public ArrayList<String> busRouteNm = new ArrayList<>();
    public ArrayList<String> length = new ArrayList<>();
    public ArrayList<String> routeType = new ArrayList<>();
    public ArrayList<String> stStationNm = new ArrayList<>();
    public ArrayList<String> edStationNm = new ArrayList<>();
    public ArrayList<String> term = new ArrayList<>();
    public ArrayList<String> lastBusYn = new ArrayList<>();
    public ArrayList<String> firstBusTm = new ArrayList<>();
    public ArrayList<String> lastBusTm = new ArrayList<>();
    public ArrayList<String> firstLowTm = new ArrayList<>();
    public ArrayList<String> lastLowTm = new ArrayList<>();
    public ArrayList<String> corpNm = new ArrayList<>();

    // tag값의 정보를 가져오는 메소드
    public static String getTagValue(String tag, Element eElement) {
        try {
            String result = eElement.getElementsByTagName(tag).item(0).getTextContent();
            return result;
        } catch (NullPointerException e) {
            return "";
        } catch (Exception e) {
            return "";
        }

    }

    public void parsing() {

        try {

            busRouteListUrl url = new busRouteListUrl();
            String view = url.getUrl();
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = f.newDocumentBuilder();

            Document doc = null;
            doc = parser.parse(view);
            doc.getDocumentElement().normalize();

            // 파싱할 tag
            NodeList nList = doc.getElementsByTagName("itemList");
            num = nList.getLength();
            System.out.println("정보 개수 : " + num);

            // 하위 엘리먼트 접근
            for (int temp = 0; temp < num; temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    
                    // 노선 ID
                    busRouteId.add(getTagValue("busRouteId", eElement));
                    //System.out.println(busRouteId.get(temp));

                    // 노선명
                    busRouteNm.add(getTagValue("busRouteNm", eElement));
                    //System.out.println(busRouteNm.get(temp));

                    // 노선길이(km)
                    length.add(getTagValue("length", eElement));
                    //System.out.println(length.get(temp));

                    // 노선 유형(1공항 2마을 3간선 4지선 5순환 6광역 7인천 8경기 9폐지 0공용)
                    routeType.add(getTagValue("routeType", eElement));
                    //System.out.println(routeType.get(temp));

                    // 기점
                    stStationNm.add(getTagValue("stStationNm", eElement));
                    //System.out.println(stStationNm.get(temp));

                    // 종점
                    edStationNm.add(getTagValue("edStationNm", eElement));
                    //System.out.println(edStationNm.get(temp));

                    // 배차간격(분)
                    term.add(getTagValue("term", eElement));
                    //System.out.println(term.get(temp));

                    // 막차운행여부
                    lastBusYn.add(getTagValue("lastBusYn", eElement));
                    //System.out.println(lastBusYn.get(temp));

                    // 금일첫차시간
                    firstBusTm.add(getTagValue("firstBusTm", eElement));
                    //System.out.println(firstBusTm.get(temp));

                    // 금일막차시간
                    lastBusTm.add(getTagValue("lastBusTm", eElement));
                    //System.out.println(lastBusTm.get(temp));

                    // 금일저상첫차시간
                    firstLowTm.add(getTagValue("firstLowTm", eElement));
                    //System.out.println(firstLowTm.get(temp));

                    // 금일저상막차시간
                    lastLowTm.add(getTagValue("lastLowTm", eElement));
                    //System.out.println(lastLowTm.get(temp));

                    // 운수사명
                    corpNm.add(getTagValue("corpNm", eElement));
                    //System.out.println(corpNm.get(temp));
                    //System.out.println("-----------------------------------------------------------------");
                } // if end(nodeType)

            } // for end (print)

        } catch (Exception e) {
            e.printStackTrace();
        } // try~catch end
    }
}
