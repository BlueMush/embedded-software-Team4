/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package parsing.busPosByRtidList;

/**
 *
 * @author fkeke
 */
public class busPosByRtidListUrl {
    private final String publicUrl = "http://ws.bus.go.kr/api/rest/buspos/";
    private final String operation = "getBusPosByRtid";
    // 공공데이터 인증키 값 설정
    private final String serviceKey = "ServiceKey=MEK%2FulhQxh%2ByoxzjTRgYXX6VEQ6OEozpUhg%2Fe38nM%2F2xqwKsivdefzwoVNdXr0sgfugqUGqT%2F6CeOAgHQp6bng%3D%3D";
    private final String parameter = "&busRouteId=";
    private final String url = publicUrl + operation + "?" + serviceKey + parameter;
    private String busRouteId;

    public String getBusRouteId() {
        return busRouteId;
    }

    public void setBusRouteId(String busRouteId) {
        this.busRouteId = busRouteId;
    }
    
    public String getUrl() {
        return url;
    }

}
