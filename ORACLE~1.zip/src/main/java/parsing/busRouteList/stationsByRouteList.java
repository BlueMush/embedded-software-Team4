/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsing.busRouteList;

import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author fkeke
 */
public class stationsByRouteList {

    private int num = 0;

    public ArrayList<String> busRouteId = new ArrayList<>(); // 노선 ID
    public ArrayList<String> busRouteNm = new ArrayList<>(); // 노선명
    public ArrayList<String> seq = new ArrayList<>(); // 순번
    public ArrayList<String> section = new ArrayList<>(); // 구간 ID
    public ArrayList<String> station = new ArrayList<>(); // 정류소 ID
    public ArrayList<String> stationNm = new ArrayList<>(); // 정류소 이름
    public ArrayList<String> gpsX = new ArrayList<>(); // X 좌표 (WGS 84)
    public ArrayList<String> gpsY = new ArrayList<>(); // Y 좌표 (WGS 84)
    public ArrayList<String> direction = new ArrayList<>(); // 진행방향
    public ArrayList<String> fullSectDist = new ArrayList<>(); // 정류소간 거리
    public ArrayList<String> stationNo = new ArrayList<>(); // 정류소 고유번호
    public ArrayList<String> routeType = new ArrayList<>(); // 노선 유형
    public ArrayList<String> beginTm = new ArrayList<>(); // 첫차 시간
    public ArrayList<String> lastTm = new ArrayList<>(); // 막차 시간
    public ArrayList<String> trnstnid = new ArrayList<>(); // 회차지 정류소 ID
    public ArrayList<String> posX = new ArrayList<>(); // 좌표 X (GRS 80)
    public ArrayList<String> posY = new ArrayList<>(); // 좌표 Y (GRS 80)
    public ArrayList<String> sectSpd = new ArrayList<>(); // 구간속도

    // tag값의 정보를 가져오는 메소드
    public static String getTagValue(String tag, Element eElement) {
        try {
            String result = eElement.getElementsByTagName(tag).item(0).getTextContent();
            return result;
        } catch (NullPointerException e) {
            return "";
        } catch (Exception e) {
            return "";
        }

    }

    public void parsing(String busRouteId_) {

        try {

            stationsByRouteListUrl stationUrl = new stationsByRouteListUrl();
            stationUrl.setBusRouteId(busRouteId_);
            String view = stationUrl.getUrl() + stationUrl.getBusRouteId();

            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = f.newDocumentBuilder();

            Document doc = null;
            doc = parser.parse(view);
            doc.getDocumentElement().normalize();

            // 파싱할 tag
            NodeList nList = doc.getElementsByTagName("itemList");
            num = nList.getLength();
            System.out.println("정보 개수 : " + num);

            // 하위 엘리먼트 접근
            for (int temp = 0; temp < num; temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;

                    busRouteId.add(getTagValue("busRouteId", eElement));
                    //System.out.println(busRouteId.get(temp));

                    busRouteNm.add(getTagValue("busRouteNm", eElement));
                    //System.out.println(busRouteNm.get(temp));

                    seq.add(getTagValue("seq", eElement));
                    //System.out.println(seq.get(temp));

                    section.add(getTagValue("section", eElement));
                    //System.out.println(section.get(temp));

                    station.add(getTagValue("station", eElement));
                    //System.out.println(station.get(temp));

                    stationNm.add(getTagValue("stationNm", eElement));
                    //System.out.println(stationNm.get(temp));

                    gpsX.add(getTagValue("gpsX", eElement));
                    //System.out.println(gpsX.get(temp));

                    gpsY.add(getTagValue("gpsY", eElement));
                    //System.out.println(gpsY.get(temp));

                    direction.add(getTagValue("direction", eElement));
                    //System.out.println(direction.get(temp));

                    fullSectDist.add(getTagValue("fullSectDist", eElement));
                    //System.out.println(fullSectDist.get(temp));

                    stationNo.add(getTagValue("stationNo", eElement));
                    //System.out.println(stationNo.get(temp));

                    routeType.add(getTagValue("routeType", eElement));
                    //System.out.println(routeType.get(temp));

                    beginTm.add(getTagValue("beginTm", eElement));
                    //System.out.println(beginTm.get(temp));

                    lastTm.add(getTagValue("lastTm", eElement));
                    //System.out.println(lastTm.get(temp));

                    trnstnid.add(getTagValue("trnstnid", eElement));
                    //System.out.println(trnstnid.get(temp));

                    posX.add(getTagValue("posX", eElement));
                    //System.out.println(posX.get(temp));

                    posY.add(getTagValue("posY", eElement));
                    //System.out.println(posY.get(temp));

                    sectSpd.add(getTagValue("sectSpd", eElement));
                    //System.out.println(sectSpd.get(temp));
                    //System.out.println("-----------------------------------------------------------------");
                } // if end(nodeType)

            } // for end (print)

        } catch (Exception e) {
            e.printStackTrace();
        } // try~catch end
    }
}