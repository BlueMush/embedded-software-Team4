package parsing;

public class Choose_Url {

    private String url = null;
    private String busRouteId;
    private String strSrch;

    public String getStrSrch() {
        return strSrch;
    }

    public void setStrSrch(String strSrch) {
        this.strSrch = strSrch;
    }
    
    public String getBusRouteId() {
        return busRouteId;
    }

    public void setBusRouteId(String busRouteId) {
        this.busRouteId = busRouteId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String info_w, String... strings) {
        Url_Info info = new Url_Info();
        String url = info.simple_Url + info_w + "?" + info.key + "&strSrch=" + getStrSrch();
        this.url = url;
    }

    public String view_List(String info_list) {

        String url = null;
        Choose_Url cu = new Choose_Url();

        cu.setStrSrch("");

        cu.setUrl(info_list, cu.getStrSrch());
        url = cu.getUrl();

        return url;
    }

}
