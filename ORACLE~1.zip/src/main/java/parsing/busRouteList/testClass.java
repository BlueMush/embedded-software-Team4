/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsing.busRouteList;

import static java.lang.Thread.sleep;

/**
 *
 * @author fkeke
 */
public class testClass {

    public static void main(String[] args) {

        busRouteList brl = new busRouteList();
        brl.parsing();
        /*
         stationsByRouteList srl = new stationsByRouteList();
         srl.parsing(brl.busRouteId.get(0));
        
         int totalElements = srl.stationNm.size();// arrayList의 요소의 갯수를 구한다.
         for (int index = 0; index < totalElements; index++) {
         System.out.println(srl.stationNm.get(index));
            
         }
        
         */

        int totalElements = brl.busRouteId.size();// arrayList의 요소의 갯수를 구한다.
        for (int index = 0; index < totalElements; index++) {
            System.out.println(brl.busRouteId.get(index));
            System.out.println(brl.busRouteNm.get(index));
            System.out.println("------------------------------------------------------");
        }
    }
}
