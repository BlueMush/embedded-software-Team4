package parsing;

public class Url_Info {

    String simple_Url = "http://ws.bus.go.kr/api/rest/busRouteInfo/";
    String key = "ServiceKey=EexLJ1QY2YFGFoq1%2FXLc%2Bb3FCzpMPTRjqHUUQ57LX5Gg%2FaZTST3gwKFIFy0CZkExacp8bLt1Fni%2F%2BROVUn7LhA%3D%3D";

    // 노선 기본 정보 항목 조회
    public static String infoItem = "getRouteInfo";
    
    // 노선 경로 목록 조회
    public static String rPathList = "getRoutePathList";

    // 노선 번호 목록 조회
    public static String busRList = "getBusRouteList";
    
    // 노선별 경유 정류소 목록 조회
    public static String stationRList = "getStationByRouteList";

}
